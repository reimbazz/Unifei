let numTentativas = 0;
let numRandom = null;

//ref para o DOM
const btnAdivinhar = document.querySelector('#btn-adivinhar');
const btnPensar = document.querySelector('#btn-pensar');

const numIni = document.querySelector('#num-ini');
const numFim = document.querySelector('#num-fim');
const numP = document.querySelector('#num-jogador');

const areaSaida = document.querySelector('#area-saida-span');

btnAdivinhar.addEventListener('click', () => {
    if(numRandom === null){
        areaSaida.innerHTML = "Calma Jovem! Nem pensei em nenhum número. Lembrou de clicar no 'Pensar'?";
        return;
    }

    let numJ = numP.value;

    if(numJ === '' || (numJ.split('.').length != 1 ) || numJ.startsWith('-')){
        areaSaida.innerHTML = 'Coloque um número valido para tentar adivinhar';
    }else{
        numTentativas++;
        if(Number(numJ) === numRandom){
            areaSaida.innerHTML = `Parabens! Vc acertou depois de ${numTentativas} tentativas.`;
            numTentativas = 0;
            numFim.value = '';
            numIni.value = '';
            numP.value = '';
            numRandom = null;
        }else if(Number(numJ) > numRandom){
            areaSaida.innerHTML = 'O número que pensei é menor';
        }else{
            areaSaida.innerHTML = 'O número que pensei é maior';
        }
    }
});

btnPensar.addEventListener('click', () => {

    let numInicio = numIni.value;
    let numFinal = numFim.value;

    if(numInicio === '' || (numInicio.split('.').length != 1 ) || numInicio.startsWith('-') || 
        numFinal === '' || (numFinal.split('.').length != 1 ) || numFinal.startsWith('-')){
            areaSaida.innerHTML = 'Insira um número válido';
    }else{
        numRandom = Math.trunc(Math.random()*(Number(numFinal) - Number(numInicio)+1)) + Number(numInicio);
        areaSaida.innerHTML = "Pronto! Pensei no número!";
    }

});